let projectCache = [];
let targetProject;

window.onload = function () {
    onLoad();
};


function onLoad() {
    if (false) {
        projectCache = ["VivoCode/app_packages_SystemUI", "VivoCode/app_packages_SmartUnlock"];
        loadProjectList(projectCache);
        document.getElementById("projectName").value = "VivoCode/app_packages_SystemUI";
    }
    document.getElementById("updateSettings").onclick = function () {
        updateSettings();
    };
    chrome.storage.local.get({'lastProject': "VivoCode/app_packages_SystemUI"}, function (result) {
        console.log(result["lastProject"] + "<<<<<lastProject result")
        targetProject = result["lastProject"];
        document.getElementById("projectName").setAttribute("value", targetProject);
    });
    chrome.storage.local.get({'historyProjectCache': []}, function (result) {
        console.log(result['historyProjectCache'] + "<<<<<historyProjectCache result")
        projectCache = result['historyProjectCache'];
        loadProjectList(projectCache);
    });
}

function loadProjectList(projectList) {
    if (null != projectList) {
        let datalist = document.getElementById("historyProjects");
        let children = datalist.childNodes;
        for (let i = children.length - 1; i >= 0; i--) {
            datalist.removeChild(children[i]);
        }

        for (let i = 0; i < projectList.length; i++) {
            let tmp = projectList[i]
            console.log("load project: " + tmp);
            let tmpOption = document.createElement('option');
            tmpOption.setAttribute("value", tmp);
            datalist.appendChild(tmpOption);
        }
    }

}

function updateSettings() {
    targetProject = document.getElementById("projectName").value;
    console.log("targetProject:" + targetProject)
    if (isEmpty(targetProject)) {
        return;
    }

    if (null != projectCache) {
        let oldPos = -1;
        for (let j = 0; j < projectCache.length; j++) {
            if (targetProject === projectCache[j]) {
                oldPos = j;
                break;
            }
        }
        if (oldPos !== -1) {
            projectCache.splice(oldPos, 1);
        }
    }
    if (null == projectCache) {
        projectCache = [targetProject]
    } else {
        projectCache.unshift(targetProject)
    }
    console.log("projectCache:" + projectCache)
    loadProjectList(projectCache)

    chrome.storage.local.set({lastProject: targetProject}, function () {
        console.log('保存成功！');
    });
    chrome.storage.local.set({historyProjectCache: projectCache}, function () {
        console.log('保存成功！');
    });
}

//判断字符是否为空的方法
function isEmpty(obj) {
    return typeof obj == "undefined" || obj == null || obj === "";
}
